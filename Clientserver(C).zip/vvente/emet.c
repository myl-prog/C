#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<string.h>
#include <arpa/inet.h>
#define TRUE 1
#define BUFSIZE 512
#define NB_CLIENTS_MAX 10
#define NORMAL "0"
#define ROUGE "31"
#define VERT  "32"
#define JAUNE  "33"
#define BLEU  "34"
#define MAG  "35"
#define CYN  "36"
#define WHT  "37"

#define couleur(param) printf("\033[%sm",param)

int main ( int argc, char *argv[])
{

 int socketAccueil, socketVente;
 char buf[BUFSIZE];
 struct sockaddr_in adr;
 struct sockaddr_in addrr;
 int lgadr;
 struct sockaddr_in adresse;
 int lg_adresse;
 struct hostent *hote;
 u_short port;
 int n, max, i,recu,envoye;

couleur(JAUNE);
if (argv[2]==NULL)
{
fprintf(stderr,"erreur argv \n" );return 0;
}
             /* tableau des sockets des clients   */
  int nbclients;
 
 if ((hote = gethostbyname(argv[2])) == NULL){ fprintf(stderr, "host by name \n"); exit(2);}
    lgadr = sizeof(adr);
     lg_adresse=sizeof(adresse);
     /* creation de la socket */
     if ((socketAccueil = socket(AF_INET, SOCK_DGRAM,0)) == -1) 
     { perror("socket");exit(1);}
      /* conversion du port passe en argument */
      
      /* attachement de la socket de RV au port */
 adr.sin_family = AF_INET;
 adr.sin_port =  htons(atoi(argv[1]));
 bcopy(hote->h_addr, &adr.sin_addr, hote->h_length);
  printf("L'adresse en notation pointee %s\n", inet_ntoa(adr.sin_addr));
char continuer='Y'; 
long int prix ,prix_m;
system("clear");
char nom[20];
printf("donnez votre nom pour participer \n");
scanf("%s",nom);
if ((envoye= sendto(socketAccueil,nom,19, 0,(struct sockaddr *)  &adr, lgadr))!=19) 
				{
				 perror("envoyerr"); exit(1);
				} 
				printf("message envoyer\n");
	while(continuer=='Y')
	{

				lgadr=sizeof(struct sockaddr_in);

				
				
				if ((recu = recvfrom(socketAccueil, buf, 256, 0,(struct sockaddr *) &adr, &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
				if (strlen(buf)==0)
				{
					printf("la vente a terminer !!!!! \n");
					break;
				}
				printf("description de la vente \n\n %s",buf);
				lgadr=sizeof(struct sockaddr_in);
		if ((recu = recvfrom(socketAccueil,&prix, sizeof(long int), 0, (struct sockaddr *) &adr, &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
				
				printf("prix actuel\n%ld Euro \n",prix);
            if(prix_m<prix){
				printf("proposez un prix ??\n");scanf("%ld",&prix_m);
				printf("prix envoye %ld\n",prix_m);
			if ((envoye= sendto(socketAccueil,&prix_m,sizeof(long int), 0,(struct sockaddr *)  &adr, lgadr))!=sizeof(long int)) 
				{
				 perror("envoyerr"); exit(1);
				} }
		}
		system("clear");
		if ((recu = recvfrom(socketAccueil,&prix, sizeof(long int), 0, (struct sockaddr *) &adr, &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
				printf("le produit est vendu avec un prix de %ld \n ",prix);
				if ((recu = recvfrom(socketAccueil, buf, 256, 0,(struct sockaddr *) &adr, &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
				printf("%s",buf);
	}
