#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<string.h>
#include <arpa/inet.h>
#define TRUE 1
#define BUFSIZE 512
#define NB_CLIENTS_MAX 10
#define NORMAL "0"
#define ROUGE "31"
#define VERT  "32"
#define JAUNE  "33"
#define BLEU  "34"
#define MAG  "35"
#define CYN  "36"
#define WHT  "37"

#define couleur(param) printf("\033[%sm",param)

int main ( int argc, char **argv){
couleur(VERT);
system("clear");
 int socketAccueil, socketVente;
 char buf[BUFSIZE];
 struct sockaddr_in adr;
 int lgadr;
 struct sockaddr_in adresse;
 int lg_adresse;
 struct hostent *hote;
 u_short port;
 int n, max, i,recu,envoye;
 fd_set fdset;
  struct sockaddr_in clients[NB_CLIENTS_MAX]; 
  struct sockaddr_in client_f;

             /* tableau des sockets des clients   */
  int nbclients;
  if (argc != 2)  
  {     printf("Usage : executable port \n"); 
   exit(2); 
    }  
     lgadr = sizeof(adr);
     lg_adresse=sizeof(adresse);
     /* creation de la socket */
     if ((socketAccueil = socket(AF_INET, SOCK_DGRAM,0)) == -1) 
     { perror("socket");exit(1);}
      /* conversion du port passe en argument */
      port = atoi(argv[1]);
      /* attachement de la socket de RV au port */
 adr.sin_family = AF_INET;
 adr.sin_port = htons(port);
 adr.sin_addr.s_addr = htonl(INADDR_ANY);
char continuer='Y'; 
int Nb_client=0;
if ((bind(socketAccueil, (struct sockaddr *) &adr, lgadr)) == -1)
	{
		perror("bind"); exit(1);
	}
	while(continuer=='Y' && Nb_client<NB_CLIENTS_MAX)
	{system("clear");
printf("attente d'un nouveau client ... \n");
				lgadr=sizeof(struct sockaddr_in);
				if ((recu = recvfrom(socketAccueil, buf, 256, 0, (struct sockaddr *) &clients[Nb_client], &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
			printf("%s veut participer non id %d  \n",buf,Nb_client+1);	
			printf("voulez vous continuer ? (Y,N)\n");
	
			scanf("%c",&continuer);
			if (continuer=='\n')
			{
				scanf("%c",&continuer);
			}
			Nb_client++;
	}
	
system("clear");
printf("la vente va commencer \n");
  /* On doit toujours scruter la socket de rendez-vous, on la met dans la case 0 */
strcpy(buf,"description de la vente un telephone condor p6 pro");
 if ((socketVente= socket(AF_INET, SOCK_DGRAM,0)) == -1) 
     { perror("socket");exit(1);}
      /* conversion du port passe en argument */
      port = atoi(argv[1]);
      /* attachement de la socket de RV au port */
 adr.sin_family = AF_INET;
 adr.sin_port = htons(port);
 adr.sin_addr.s_addr = htonl(INADDR_ANY);
long int prix = 100,prix_2=0;
int client =0;
continuer='N';
  while (continuer=='N') 
  {
  	for(i=0;i<Nb_client;i++)
			{	
				printf("envoi loffre au clients %d \n le prix actuel %ld euro\n",i+1,prix);
				lgadr=sizeof(struct sockaddr_in);
				if ((envoye= sendto(socketVente, buf,strlen(buf)+1, 0, (struct sockaddr *) &clients[i], lgadr))!=strlen(buf)+1) 
				{
				 perror("envoyerr"); exit(1);
				} 
				
			if ((envoye= sendto(socketVente,&prix,sizeof(long int), 0, (struct sockaddr *) &clients[i], lgadr))!=sizeof(long int)) 
				{
				 perror("envoyerr"); exit(1);
				} 
			}
			if ((recu = recvfrom(socketVente, &prix_2,sizeof(long int), 0,  (struct sockaddr *)&client_f, &lgadr)) == -1) 
				{
				 perror("recvfrom"); exit(1);
				} 
				
			if(prix_2>prix)
			{system("clear");
				prix=prix_2;
			printf("un  client  a proposer un prix de %ld euro\n voulez vous vendre? (Y,N)\n",prix);
			
			scanf("%c",&continuer);
			if (continuer=='\n')
			{
				scanf("%c",&continuer);
			}
			}
			
			
      }
system("clear");

	lgadr=sizeof(struct sockaddr_in);
	buf[0]='\0';
	couleur(CYN);
printf("vous avez vendu le produit au prix de %ld\n", prix);
  	for(i=0;i<Nb_client;i++)
			{	

if ((envoye= sendto(socketVente,buf,1, 0,  (struct sockaddr *)&clients[i], lgadr))!=1) 
				{
				 perror("envoyerr"); exit(1);
				} 
	if ((envoye= sendto(socketVente,&prix,sizeof(long int), 0,  (struct sockaddr *)&clients[i], lgadr))!=sizeof(long int)) 
				{
				 perror("envoyerr"); exit(1);
				} 

     }
strcpy(buf,"felicitation vous avez acheter le produit \n le colie sera expidié demain matin \n");
	if ((envoye= sendto(socketVente,buf,strlen(buf)+1, 0,  (struct sockaddr *)&client_f, lgadr))!=strlen(buf)+1) 
				{
				 perror("envoyerr"); exit(1);
				} 
  }
   